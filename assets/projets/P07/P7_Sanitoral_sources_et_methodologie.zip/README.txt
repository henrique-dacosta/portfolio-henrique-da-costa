Projet P7 - Sanitoral / Power BI

Contenu :
- Donnees_Sanitoral.xlsx : fichier source pedagogique
- Dictionnaire_des_donnees.xlsx : description des champs
- Note_de_cadrage_Sanitoral.pdf : besoins, utilisateurs et specifications
- Preparation_des_donnees_et_modelisation.pdf : travaux Power Query, modele et DAX
- Modele_Product_Strategy_Canvas.docx : trame pedagogique du canvas

Le Product Strategy Canvas complete figure dans le PDF du tableau de bord.
Ces fichiers sont issus d'un projet pedagogique OpenClassrooms et ne contiennent pas de donnees personnelles.
