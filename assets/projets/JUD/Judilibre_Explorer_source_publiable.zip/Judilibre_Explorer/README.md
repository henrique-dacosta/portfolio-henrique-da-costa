# Judilibre Explorer

Application Streamlit de recherche, consultation et export de décisions
de jurisprudence via l'API Judilibre / PISTE.

## Fonctionnalités

- recherche plein texte avec opérateurs OR, AND et EXACT ;
- filtres par juridiction, chambre et période ;
- limitation du volume et pagination locale ;
- affichage des métadonnées et résumés rapides ;
- récupération du texte intégral d'une décision ;
- exports CSV, Excel, Word, PDF et ZIP.

## Installation locale

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Configuration de la clé API

Créez le fichier `.streamlit/secrets.toml` :

```toml
judilibre_key = "VOTRE_CLE_API_PISTE_PRODUCTION"
```

Ce fichier ne doit jamais être publié ni ajouté au dépôt Git.

Pour Streamlit Community Cloud, configurez la même variable dans les
secrets de l'application.

## Sécurité

La version publiable exclut :

- `.streamlit/secrets.toml` ;
- `.venv` ;
- les caches Python ;
- toute clé API ou jeton d'accès.

Toute clé déjà affichée dans une capture d'écran, un historique de commandes
ou un dépôt doit être révoquée puis régénérée avant le déploiement.

## Architecture

`Besoin métier -> API Judilibre -> Interface Streamlit -> Filtrage et lecture -> Exports`

## Limites

La qualité et la disponibilité des résultats dépendent du service PISTE.
Une erreur de l'API externe ne signifie pas nécessairement une erreur du code.
