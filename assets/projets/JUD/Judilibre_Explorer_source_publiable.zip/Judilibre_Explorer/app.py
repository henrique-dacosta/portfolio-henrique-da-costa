import calendar
from datetime import date
from io import BytesIO
import textwrap  # pour certains traitements éventuels
from xml.sax.saxutils import escape  # pour le PDF justifié

import pandas as pd
import requests
import streamlit as st

import io
import zipfile
import datetime

# ---------------------------------------------------------
# Imports optionnels pour Word / PDF
# ---------------------------------------------------------
try:
    from docx import Document  # python-docx
except ImportError:  # bibliothèque non installée
    Document = None  # type: ignore

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
except ImportError:  # bibliothèque non installée
    A4 = None  # type: ignore
    canvas = None  # type: ignore


# ---------------------------------------------------------
# Configuration générale
# ---------------------------------------------------------
st.set_page_config(
    page_title="Recherche Judilibre",
    layout="wide",
)

# Clé API stockée dans .streamlit/secrets.toml
# contenu du fichier :
# judilibre_key = "ta_cle_piste_ici"
try:
    KEY_ID = st.secrets.get("judilibre_key")
except Exception:
    KEY_ID = None

if not KEY_ID:
    st.warning(
        "Clé API Judilibre non configurée. Ajoutez `judilibre_key` dans "
        "`.streamlit/secrets.toml` ou dans les secrets Streamlit Cloud."
    )

BASE_URL = "https://api.piste.gouv.fr/cassation/judilibre/v1.0"
SEARCH_URL = f"{BASE_URL}/search"
DECISION_URL = f"{BASE_URL}/decision"

# Paramètres globaux
PAGE_SIZE_API = 50         # taille d'une page côté API (max Judilibre)
PAGE_SIZE_TABLE = 50       # valeur par défaut, rendue dynamique via la sidebar
MAX_PAGES_HARD = 20        # garde-fou absolu : 20 * 50 = 1000 résultats max

# ===== Initialisation du session_state =====
if "df_results" not in st.session_state:
    st.session_state.df_results = None
if "meta_info" not in st.session_state:
    st.session_state.meta_info = None
if "full_decision" not in st.session_state:
    st.session_state.full_decision = None
if "decision_id_input" not in st.session_state:
    st.session_state.decision_id_input = ""
if "max_rows_limit" not in st.session_state:
    # valeur par défaut : 100 (2 pages de 50)
    st.session_state.max_rows_limit = 100
# pour le ZIP
if "decisions_cache" not in st.session_state:
    st.session_state.decisions_cache = {}
if "zip_all_decisions" not in st.session_state:
    st.session_state.zip_all_decisions = None


# ---------------------------------------------------------
# Fonctions utilitaires
# ---------------------------------------------------------
@st.cache_data(show_spinner=False)
def search_judilibre(
    query: str,
    jurisdiction: str | None,
    chamber: str | None,
    page: int,
    page_size: int = PAGE_SIZE_API,
    operator: str = "or",
) -> dict:
    """
    Appelle l'endpoint /search de Judilibre et renvoie le JSON brut
    pour une page donnée.
    """
    if not KEY_ID:
        raise RuntimeError(
            "Clé API absente. Ajoute judilibre_key dans .streamlit/secrets.toml"
        )

    params = {
        "query": query,
        "page": page,
        "page_size": page_size,
        "operator": operator,
    }

    if jurisdiction:
        params["jurisdiction"] = jurisdiction
    if chamber:
        params["chamber"] = chamber

    # IMPORTANT : on NE met PAS les dates ici, on filtrera nous-mêmes
    headers = {
        "KeyId": KEY_ID,
        "Accept": "application/json",
    }

    resp = requests.get(SEARCH_URL, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


@st.cache_data(show_spinner=False)
def get_decision(decision_id: str) -> dict:
    """Récupère une décision complète par son id."""
    if not KEY_ID:
        raise RuntimeError(
            "Clé API absente. Ajoute judilibre_key dans .streamlit/secrets.toml"
        )

    headers = {
        "KeyId": KEY_ID,
        "Accept": "application/json",
    }
    params = {"id": decision_id}

    resp = requests.get(DECISION_URL, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


def build_heuristic_summary(text: str | None, max_lines: int = 20) -> str:
    """
    Résumé heuristique d'une décision.

    1. Essaie d'abord de récupérer les paragraphes "FAITS / FAITS ET PROCÉDURE"
       + "PAR CES MOTIFS".
    2. Si c'est trop pauvre, deuxième passe :
       prend les premières lignes contenant "ATTENDU" ou "SUR LE MOYEN".
    3. En dernier recours, retombe sur les premières lignes non vides.
    """
    if not text:
        return ""

    # Normalisation des sauts de ligne
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")

    # ---------- Découpage en paragraphes ----------
    paragraphs = [p.strip() for p in normalized.split("\n\n") if p.strip()]

    def find_index_with(keyword: str) -> int | None:
        kw = keyword.upper()
        for i, p in enumerate(paragraphs):
            if kw in p.upper():
                return i
        return None

    # Recherche des sections intéressantes
    facts_idx = find_index_with("FAITS ET PROCÉDURE")
    if facts_idx is None:
        facts_idx = find_index_with("FAITS")

    motifs_idx = find_index_with("PAR CES MOTIFS")

    selected_paragraphs: list[str] = []

    # 1) Faits / faits et procédure : 1 à 2 paragraphes
    if facts_idx is not None:
        selected_paragraphs.extend(paragraphs[facts_idx: facts_idx + 2])

    # 2) Dispositif : "PAR CES MOTIFS"
    if motifs_idx is not None and motifs_idx not in range(
        facts_idx or -1, (facts_idx or -1) + 2
    ):
        selected_paragraphs.append(paragraphs[motifs_idx])

    # Assemblage provisoire du résumé à partir de ces paragraphes
    summary = ""
    if selected_paragraphs:
        summary = "\n\n".join(selected_paragraphs)

    # ---------- Deuxième passe : "ATTENDU" / "SUR LE MOYEN" ----------
    lines = [ln.strip() for ln in normalized.splitlines() if ln.strip()]

    def first_index_with_any(keywords: list[str]) -> int | None:
        uppers = [k.upper() for k in keywords]
        for i, ln in enumerate(lines):
            up = ln.upper()
            if any(k in up for k in uppers):
                return i
        return None

    if not summary or len(summary) < 300:
        idx = first_index_with_any(
            ["ATTENDU", "SUR LE MOYEN", "SUR LE PREMIER MOYEN"]
        )
        if idx is not None:
            block = lines[idx: idx + max_lines]
            summary2 = "\n".join(block)
            if len(summary2) > len(summary):
                summary = summary2

    # ---------- Dernier recours ----------
    if not summary:
        if not lines:
            return ""
        summary = "\n".join(lines[:max_lines])

    # Limites de taille
    summary_lines = summary.splitlines()
    if len(summary_lines) > max_lines:
        summary = "\n".join(summary_lines[:max_lines])

    max_chars = 2000
    if len(summary) > max_chars:
        cut_pos = summary.rfind("\n", 0, max_chars)
        if cut_pos == -1:
            cut_pos = max_chars
        summary = summary[:cut_pos] + "\n[...]"

    return summary


def last_day_of_month(year: int, month: int) -> int:
    return calendar.monthrange(year, month)[1]


def make_docx(decision_id: str, meta: dict, text: str) -> BytesIO:
    """
    Crée un fichier Word (docx) en mémoire à partir de la décision,
    avec titre + en-tête centrés et corps du texte justifié.
    Numéro de page centré en pied de page.
    """
    if Document is None:
        raise RuntimeError(
            "Le module python-docx n'est pas installé. "
            "Installe-le avec : pip install python-docx"
        )

    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    doc = Document()

    # Titre centré
    title = doc.add_heading(f"Décision {decision_id}", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Métadonnées centrées
    for label, value in meta.items():
        if value:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run_label = p.add_run(f"{label} : ")
            run_label.bold = True
            p.add_run(str(value))

    doc.add_paragraph("")

    # Corps du texte : paragraphes justifiés
    for block in text.split("\n\n"):
        block = block.strip()
        if not block:
            doc.add_paragraph("")
            continue
        p = doc.add_paragraph(block)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # Pied de page avec numéro de page centré
    section = doc.sections[0]
    footer = section.footer
    p_footer = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p_footer.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = p_footer.add_run()

    # Champ Word pour numéro de page : { PAGE }
    fld_char_begin = OxmlElement("w:fldChar")
    fld_char_begin.set(qn("w:fldCharType"), "begin")

    instr_text = OxmlElement("w:instrText")
    instr_text.text = "PAGE"

    fld_char_end = OxmlElement("w:fldChar")
    fld_char_end.set(qn("w:fldCharType"), "end")

    run._r.append(fld_char_begin)
    run._r.append(instr_text)
    run._r.append(fld_char_end)

    bio = BytesIO()
    doc.save(bio)
    bio.seek(0)
    return bio


def make_pdf(decision_id: str, meta: dict, text: str) -> BytesIO:
    """
    Crée un fichier PDF en mémoire à partir de la décision,
    avec titre + métadonnées centrés, corps du texte justifié
    et numérotation de page centrée en bas.
    """
    if A4 is None or canvas is None:
        raise RuntimeError(
            "Le module reportlab n'est pas installé. "
            "Installe-le avec : pip install reportlab"
        )

    bio = BytesIO()

    # Document platypus pour gérer facilement la justification
    doc = SimpleDocTemplate(
        bio,
        pagesize=A4,
        leftMargin=40,
        rightMargin=40,
        topMargin=50,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleCenter",
        parent=styles["Heading1"],
        alignment=TA_CENTER,
    )
    meta_style = ParagraphStyle(
        "MetaCenter",
        parent=styles["Normal"],
        alignment=TA_CENTER,
        leading=12,
    )
    body_style = ParagraphStyle(
        "BodyJustify",
        parent=styles["Normal"],
        alignment=TA_JUSTIFY,
        leading=12,
    )

    story = []

    # Titre
    story.append(Paragraph(escape(f"Décision {decision_id}"), title_style))
    story.append(Spacer(1, 20))

    # Métadonnées centrées
    for label, value in meta.items():
        if value:
            line = f"{label} : {value}"
            story.append(Paragraph(escape(line), meta_style))
            story.append(Spacer(1, 5))

    story.append(Spacer(1, 15))

    # Corps du texte justifié : on découpe sur les doubles sauts de ligne
    for block in text.split("\n\n"):
        block = block.strip()
        if not block:
            story.append(Spacer(1, 8))
            continue
        # Paragraph interprète <, & ... comme balises, donc on échappe
        safe_block = escape(block.replace("\n", " "))
        story.append(Paragraph(safe_block, body_style))
        story.append(Spacer(1, 4))

    # Callback pour la numérotation de pages
    def _add_page_number(canv, document):
        page_num = canv.getPageNumber()
        canv.setFont("Helvetica", 9)
        canv.drawCentredString(A4[0] / 2, 20, f"Page {page_num}")

    doc.build(
        story,
        onFirstPage=_add_page_number,
        onLaterPages=_add_page_number,
    )

    bio.seek(0)
    return bio


# ---------------------------------------------------------
# Barre latérale : paramètres de recherche
# ---------------------------------------------------------
st.sidebar.header("Paramètres de recherche")

# Aide-mémo d'utilisation
with st.sidebar.expander("Aide-mémo d'utilisation"):
    st.markdown(
        """
        **1. Requête (query)**  
        - Entrez des mots-clés entre guillemets : `"enquête" "harcèlement" "biaisée"`.  
        - Le comportement dépend du *Mode de recherche* sélectionné :  
          - **OR** : au moins un des mots apparaît dans la décision.  
          - **AND** : tous les mots doivent apparaître.  
          - **EXACT** : la requête est utilisée telle quelle (utile pour une expression précise).  

        **2. Filtres (juridiction, chambre, dates)**  
        - Limitez la recherche à la **Cour de cassation** ou aux **Cours d'appel**.  
        - Précisez éventuellement la chambre (ex. `soc`, `civ1`, etc.).  
        - Filtrez par mois/année de décision ; le filtrage de dates est appliqué dans l'application
          après la récupération des résultats Judilibre.  

        **3. Volume de décisions**  
        - *Nombre maximum de décisions à charger* : borne haute globale (jusqu'à 1000).  
        - *Décisions par page (affichage)* : nombre de lignes visibles dans le tableau par page.  

        **4. Options de performance**  
        - **Utiliser des résumés rapides** : plus rapide (pas de chargement immédiat du texte intégral).  
        - **Activer l'export des textes (ZIP)** : permet de générer un PDF par décision pour la
          page de résultats affichée.  

        **5. Résultats et exports**  
        - Les décisions sont triées par **score décroissant** (pertinence Judilibre).  
        - Naviguez entre les pages grâce au champ *Page*.  
        - Exports disponibles :  
          - **CSV** des résultats,  
          - **Excel (xlsx)**,  
          - **ZIP** de PDF pour toutes les décisions de la **page affichée**.  

        **6. Texte complet d'une décision**  
        - Dans le tableau, copiez l'**id** de la décision qui vous intéresse.  
        - Collez cet id dans le champ *ID de décision à afficher*, puis cliquez sur
          **Charger la décision**.  
        - Le texte intégral s'affiche ; vous pouvez alors l'exporter en **Word (docx)** ou en **PDF**.  
        """
    )

default_query = '"requête une" "requête deux" "..."'
query = st.sidebar.text_input("Requête (query)", value=default_query)

# Opérateur de recherche Judilibre
operator_label = st.sidebar.radio(
    "Mode de recherche",
    options=[
        "OR – au moins un des termes",
        "AND – tous les termes",
        "EXACT – requête exacte",
    ],
    index=0,
)

if operator_label.startswith("OR"):
    operator_param = "or"
elif operator_label.startswith("AND"):
    operator_param = "and"
else:
    operator_param = "exact"

# Juridiction
juridiction_label = st.sidebar.selectbox(
    "Juridiction",
    options=["Toutes juridictions", "Cour de cassation", "Cours d'appel"],
    index=1,  # défaut : Cassation
)

if juridiction_label == "Cour de cassation":
    jurisdiction_param: str | None = "cc"
elif juridiction_label == "Cours d'appel":
    jurisdiction_param = "ca"
else:
    jurisdiction_param = None

# Chambres
CASSATION_CHAMBERS = [
    "(Toutes chambres)",
    "soc",
    "cr",
    "civ1",
    "civ2",
    "civ3",
    "com",
    "mixte",
    "asspl",
]

APPEL_CHAMBERS = [
    "(Toutes chambres)",
    "chambre sociale",
    "chambre civile",
    "chambre commerciale",
    "chambre correctionnelle",
]

if juridiction_label == "Cour de cassation":
    chamber_choice = st.sidebar.selectbox("Chambre", CASSATION_CHAMBERS, index=1)
elif juridiction_label == "Cours d'appel":
    chamber_choice = st.sidebar.selectbox("Chambre", APPEL_CHAMBERS, index=0)
else:
    chamber_choice = st.sidebar.selectbox("Chambre", ["(Toutes chambres)"], index=0)

if chamber_choice == "(Toutes chambres)":
    chamber_param: str | None = None
else:
    chamber_param = chamber_choice

# Intervalle de dates (mois/année)
st.sidebar.markdown("### Intervalle de dates (mois/année)")

current_year = date.today().year
years = ["(aucune)"] + [str(y) for y in range(1950, current_year + 1)]
months = ["(aucun)"] + [f"{m:02d}" for m in range(1, 13)]

col_deb1, col_deb2 = st.sidebar.columns(2)
with col_deb1:
    month_start_label = st.selectbox(
        "Mois début",
        months,
        index=0,
        key="month_start",
    )
with col_deb2:
    year_start_label = st.selectbox(
        "Année début",
        years,
        index=0,
        key="year_start",
    )

col_fin1, col_fin2 = st.sidebar.columns(2)
with col_fin1:
    month_end_label = st.selectbox(
        "Mois fin",
        months,
        index=0,
        key="month_end",
    )
with col_fin2:
    year_end_label = st.selectbox(
        "Année fin",
        years,
        index=0,
        key="year_end",
    )

date_min: str | None = None
date_max: str | None = None

if month_start_label != "(aucun)" and year_start_label != "(aucune)":
    y_start = int(year_start_label)
    m_start = int(month_start_label)
    date_min = f"{y_start}-{m_start:02d}-01"

if month_end_label != "(aucun)" and year_end_label != "(aucune)":
    y_end = int(year_end_label)
    m_end = int(month_end_label)
    last_day = last_day_of_month(y_end, m_end)
    date_max = f"{y_end}-{m_end:02d}-{last_day:02d}"

# Volume de décisions
st.sidebar.markdown("### Volume de décisions")

max_results = st.sidebar.number_input(
    "Nombre maximum de décisions à charger",
    min_value=1,
    max_value=MAX_PAGES_HARD * PAGE_SIZE_API,  # 1000
    value=st.session_state.max_rows_limit,      # valeur rappelée
    step=10,
)

# On mémorise le choix pour la recherche et pour l'affichage
st.session_state.max_rows_limit = int(max_results)

# Nombre de décisions par page (affichage)
PAGE_SIZE_TABLE = int(
    st.sidebar.number_input(
        "Décisions par page (affichage)",
        min_value=10,
        max_value=200,
        value=PAGE_SIZE_TABLE,  # valeur par défaut = 50
        step=10,
    )
)

# Options de performance
fast_summaries = st.sidebar.checkbox(
    "Utiliser des résumés rapides (chargement plus rapide)",
    value=True,
)

prepare_zip_ui = st.sidebar.checkbox(
    "Activer l'export des textes (ZIP)",
    value=True,
)

st.sidebar.markdown("---")
do_search = st.sidebar.button("Lancer la recherche")


# ---------------------------------------------------------
# Corps de page : titre
# ---------------------------------------------------------
st.title(f"Recherche Judilibre – {query}")
st.caption(f"Mode de recherche : {operator_param.upper()}")


# ---------------------------------------------------------
# Lancer la recherche : appels API + stockage
# ---------------------------------------------------------
if do_search:
    # reset de l'état dépendant de la recherche
    st.session_state.full_decision = None
    st.session_state.decision_id_input = ""
    st.session_state.decisions_cache = {}
    st.session_state.zip_all_decisions = None
    # on efface aussi les résultats affichés précédemment
    st.session_state.df_results = None
    st.session_state.meta_info = None

    with st.spinner("Recherche en cours, merci de patienter..."):
        try:
            all_results: list[dict] = []

            # Limite choisie par l'utilisateur (ex : 100, 300, 1000…)
            max_rows = int(st.session_state.max_rows_limit)

            # Nombre de pages API nécessaires pour atteindre (au plus) max_rows
            max_pages_api = min(
                MAX_PAGES_HARD,
                (max_rows - 1) // PAGE_SIZE_API + 1,  # arrondi supérieur
            )

            for page in range(max_pages_api):
                data = search_judilibre(
                    query=query,
                    jurisdiction=jurisdiction_param,
                    chamber=chamber_param,
                    page=page,
                    page_size=PAGE_SIZE_API,
                    operator=operator_param,
                )
                results_page = data.get("results", []) or []
                if not results_page:
                    break

                all_results.extend(results_page)

                # Si la page est incomplète, il n'y a plus de pages suivantes
                if len(results_page) < PAGE_SIZE_API:
                    break

            # On tronque en fonction du nombre demandé
            all_results = all_results[:max_rows]

            # --- Application des bornes de dates en local ---
            dt_min = datetime.date.fromisoformat(date_min) if date_min else None
            dt_max = datetime.date.fromisoformat(date_max) if date_max else None

            filtered_results: list[dict] = []

            for res in all_results:
                d_str = res.get("decision_date")

                if not dt_min and not dt_max:
                    filtered_results.append(res)
                    continue

                if not d_str:
                    continue

                try:
                    d_obj = datetime.date.fromisoformat(d_str)
                except ValueError:
                    continue

                if dt_min and d_obj < dt_min:
                    continue
                if dt_max and d_obj > dt_max:
                    continue

                filtered_results.append(res)

            total_after_filter = len(filtered_results)

            if not filtered_results:
                st.session_state.df_results = pd.DataFrame()
                st.session_state.meta_info = {"total": 0}
            else:
                filtered_results.sort(
                    key=lambda r: (r.get("score") or 0.0),
                    reverse=True,
                )

                rows = []
                for res in filtered_results:
                    decision_id = res.get("id", "")

                    if fast_summaries:
                        # Mode rapide : pas d'appel /decision ici
                        full_text = None
                        resume_heuristique = (
                            res.get("summary")
                            or "(Résumé non disponible en mode rapide. "
                               "Consulte le texte complet si besoin.)"
                        )
                    else:
                        # Mode complet : on récupère le texte intégral
                        try:
                            dec = get_decision(decision_id)
                            full_text = dec.get("text") or dec.get("summary") or ""
                        except Exception:
                            full_text = ""

                        st.session_state.decisions_cache[decision_id] = full_text
                        resume_heuristique = build_heuristic_summary(
                            full_text, max_lines=20
                        )

                    rows.append(
                        {
                            "id": decision_id,
                            "score": res.get("score"),
                            "résumé": resume_heuristique,
                            "juridiction": res.get("jurisdiction"),
                            "chambre": res.get("chamber"),
                            "numéro": res.get("number"),
                            "date": res.get("decision_date"),
                            "solution": res.get("solution"),
                            "ecli": res.get("ecli"),
                        }
                    )

                df = pd.DataFrame(rows)
                st.session_state.df_results = df
                st.session_state.meta_info = {
                    "total": total_after_filter,
                }

        except Exception as e:  # noqa: BLE001
            st.session_state.df_results = None
            st.session_state.meta_info = None
            st.error(f"Erreur lors de l'appel à l'API Judilibre : {e}")


# ---------------------------------------------------------------
# Affichage des résultats + exports
# ---------------------------------------------------------------
df = st.session_state.df_results
meta = st.session_state.meta_info

if df is not None and meta is not None and not df.empty:
    total_rows = len(df)
    total_filtered = meta.get("total", total_rows)
    limit_rows = st.session_state.get("max_rows_limit", total_rows)

    st.markdown(
        "**Décisions présentant l'occurrence la plus élevée avec la requête**  \n"
        f"- Décisions trouvées après filtrage (dates, juridiction, chambre) : "
        f"**{total_filtered}**.  \n"
        f"- Décisions actuellement chargées dans l'application : **{total_rows}** "
        f"(limite {limit_rows}).  \n"
        f"- Affichage paginé : **{PAGE_SIZE_TABLE} décisions par page**."
    )

    st.subheader("Résultats de la recherche")

    # Pagination locale
    nb_pages = (total_rows - 1) // PAGE_SIZE_TABLE + 1
    page_sel = st.number_input(
        "Page",
        min_value=1,
        max_value=nb_pages,
        value=1,
        step=1,
    )

    start = (page_sel - 1) * PAGE_SIZE_TABLE
    end = min(start + PAGE_SIZE_TABLE, total_rows)
    df_page = df.iloc[start:end].copy()
    df_page.reset_index(drop=True, inplace=True)

    st.caption(
        f"Page {page_sel}/{nb_pages} – décisions {start + 1} à {end} sur {total_rows}."
    )

    editor_key = f"results_page_{page_sel}"

    # Tableau en lecture seule
    st.data_editor(
        df_page,
        key=editor_key,
        width="stretch",
        hide_index=True,
        disabled=True,
        column_config={
            "id": st.column_config.TextColumn("id", width=220),
            "score": st.column_config.NumberColumn("score", format="%.3f", width=70),
            "résumé": st.column_config.TextColumn("résumé", width=400),
            "juridiction": st.column_config.TextColumn("juridiction", width=80),
            "chambre": st.column_config.TextColumn("chambre", width=90),
            "numéro": st.column_config.TextColumn("numéro", width=90),
            "date": st.column_config.TextColumn("date", width=90),
            "solution": st.column_config.TextColumn("solution", width=90),
            "ecli": st.column_config.TextColumn("ecli", width=160),
        },
    )

    st.subheader("Export des résultats")

    df_results = st.session_state.df_results

    # 3 colonnes : CSV / Excel / ZIP
    col1, col2, col3 = st.columns(3)

    # ---- Export CSV ----
    with col1:
        csv_data = df_results.to_csv(index=False).encode("utf-8-sig")
        st.download_button(
            "Export CSV",
            data=csv_data,
            file_name="judilibre_resultats.csv",
            mime="text/csv",
        )

    # ---- Export Excel ----
    with col2:
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="xlsxwriter") as writer:
            df_results.to_excel(writer, index=False, sheet_name="Résultats")
        excel_buffer.seek(0)
        st.download_button(
            "Export Excel (xlsx)",
            data=excel_buffer,
            file_name="judilibre_resultats.xlsx",
            mime=(
                "application/vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            ),
        )

    # ---- Export ZIP des textes complets (page affichée) ----
    with col3:
        if prepare_zip_ui:
            st.write(
                f"{len(df_page)} décision(s) sur la page affichée "
                "seront incluses dans le ZIP."
            )

            if st.button("Générer le ZIP des décisions de la page affichée"):
                zip_buffer = io.BytesIO()
                with zipfile.ZipFile(
                    zip_buffer, "w", zipfile.ZIP_DEFLATED
                ) as zf:
                    for _, row in df_page.iterrows():
                        did = row["id"]

                        text = st.session_state.decisions_cache.get(did) or ""
                        if not text:
                            # Si le texte n'est pas déjà en cache,
                            # on le récupère maintenant
                            try:
                                dec = get_decision(did)
                                text = dec.get("text") or dec.get("summary") or ""
                            except Exception:
                                text = "(Texte non disponible)"

                        meta_zip = {
                            "Juridiction": row.get("juridiction"),
                            "Chambre": row.get("chambre"),
                            "Date": row.get("date"),
                            "Numéro": row.get("numéro"),
                            "Solution": row.get("solution"),
                        }

                        pdf_buffer = make_pdf(did, meta_zip, text)
                        pdf_bytes = pdf_buffer.getvalue()

                        date_str = str(row.get("date") or "").replace(" ", "_")
                        num_str = str(row.get("numéro") or "").replace(" ", "_")
                        if not num_str:
                            num_str = did[:8]
                        filename = f"{date_str}_{num_str}.pdf".strip("_")

                        zf.writestr(filename, pdf_bytes)

                zip_buffer.seek(0)
                st.session_state.zip_all_decisions = zip_buffer.getvalue()

            if st.session_state.zip_all_decisions:
                st.download_button(
                    "Télécharger le ZIP des décisions de la page affichée",
                    data=st.session_state.zip_all_decisions,
                    file_name=(
                        f"judilibre_textes_page_"
                        f"{page_sel}_{datetime.date.today()}.zip"
                    ),
                    mime="application/zip",
                )
        else:
            st.info(
                "Coche l'option « Activer l'export des textes (ZIP) » "
                "dans la barre latérale pour préparer un ZIP."
            )
else:
    st.info("Aucun résultat à afficher ou à exporter pour le moment.")


# ---------------------------------------------------------
# Texte complet d'une décision + export Word / PDF
# ---------------------------------------------------------
st.markdown("---")
st.subheader("Texte complet d'une décision")

decision_id_input = st.text_input(
    "ID de décision à afficher",
    key="decision_id_input",
    placeholder="Copie/colle un id depuis le tableau ci-dessus",
)

if st.button("Charger la décision"):
    if not decision_id_input.strip():
        st.warning("Merci de saisir un identifiant de décision.")
    else:
        try:
            dec_full = get_decision(decision_id_input.strip())
        except Exception as e:  # noqa: BLE001
            st.error(f"Erreur lors de la récupération de la décision : {e}")
            st.session_state.full_decision = None
        else:
            meta_dec = {
                "Juridiction": dec_full.get("jurisdiction"),
                "Chambre": dec_full.get("chamber"),
                "Date": dec_full.get("decision_date"),
                "Numéro": dec_full.get("number"),
                "Solution": dec_full.get("solution"),
            }
            texte_integral = dec_full.get("text") or dec_full.get("summary") or ""
            st.session_state.full_decision = {
                "id": dec_full.get("id") or decision_id_input.strip(),
                "meta": meta_dec,
                "text": texte_integral,
            }

full_decision = st.session_state.full_decision

if full_decision and full_decision.get("text"):
    meta_dec = full_decision["meta"]
    texte_integral = full_decision["text"]
    dec_id = full_decision["id"]

    header_md = (
        f"**Juridiction :** {meta_dec.get('Juridiction')}  \n"
        f"**Chambre :** {meta_dec.get('Chambre')}  \n"
        f"**Date :** {meta_dec.get('Date')}  \n"
        f"**Numéro :** {meta_dec.get('Numéro')}  \n"
        f"**Solution :** {meta_dec.get('Solution')}"
    )
    st.markdown(header_md)
    st.markdown("---")

    st.text_area(
        "Texte intégral",
        value=texte_integral,
        height=400,
    )

    st.markdown("### Export du texte complet")

    col_word, col_pdf = st.columns(2)

    with col_word:
        try:
            docx_buffer = make_docx(dec_id, meta_dec, texte_integral)
            st.download_button(
                "Export Word (docx)",
                data=docx_buffer,
                file_name=f"decision_{dec_id}.docx",
                mime=(
                    "application/"
                    "vnd.openxmlformats-officedocument.wordprocessingml.document"
                ),
            )
        except RuntimeError as e:
            st.info(str(e))

    with col_pdf:
        try:
            pdf_buffer = make_pdf(dec_id, meta_dec, texte_integral)
            st.download_button(
                "Export PDF",
                data=pdf_buffer,
                file_name=f"decision_{dec_id}.pdf",
                mime="application/pdf",
            )
        except RuntimeError as e:
            st.info(str(e))
else:
    st.info(
        "Saisis un identifiant de décision puis clique sur **Charger la décision** "
        "pour afficher et exporter le texte complet."
    )
